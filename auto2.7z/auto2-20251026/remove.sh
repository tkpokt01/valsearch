rm active.txt
rm exited.txt
rm val.txt
rm ev.txt
