./activelist
echo
