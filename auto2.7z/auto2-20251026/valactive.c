#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct AddressNode {
    char address[41];
    unsigned long long balance_gwei;
    struct AddressNode *next;
} AddressNode;

void add_to_list(AddressNode **head, const char *address, unsigned long long balance) {
    AddressNode *current = *head;
    while (current != NULL) {
        if (strcmp(current->address, address) == 0) {
            current->balance_gwei += balance;
            return;
        }
        current = current->next;
    }
    AddressNode *new_node = (AddressNode *)malloc(sizeof(AddressNode));
    strncpy(new_node->address, address, 40);
    new_node->address[40] = '\0';
    new_node->balance_gwei = balance;
    new_node->next = *head;
    *head = new_node;
}

int main() {
    FILE *fp = fopen("val.txt", "r");
    if (!fp) {
        perror("Failed to open val.txt");
        return 1;
    }

    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *buffer = (char *)malloc(size + 1);
    if (!buffer) {
        perror("Failed to allocate memory");
        fclose(fp);
        return 1;
    }
    fread(buffer, 1, size, fp);
    buffer[size] = '\0';
    fclose(fp);

    AddressNode *head = NULL;
    char *pos = buffer;

    while ((pos = strstr(pos, "\"status\": \"active_ongoing\"")) != NULL) {
        char *validator_start = strstr(pos, "\"validator\": {");
        if (!validator_start) {
            pos += strlen("\"status\": \"active_ongoing\"");
            continue;
        }

        char *wc_pos = strstr(validator_start, "\"withdrawal_credentials\": \"");
        if (!wc_pos) {
            pos += strlen("\"status\": \"active_ongoing\"");
            continue;
        }
        char *wc_start = wc_pos + strlen("\"withdrawal_credentials\": \"");
        char *wc_end = strchr(wc_start, '"');
        if (!wc_end || (wc_end - wc_start) < 64) {
            pos += strlen("\"status\": \"active_ongoing\"");
            continue;
        }
        char wc[67];
        strncpy(wc, wc_start, wc_end - wc_start);
        wc[wc_end - wc_start] = '\0';

        if (strlen(wc) != 66) {
            pos += strlen("\"status\": \"active_ongoing\"");
            continue;
        }
        char address[41];
        strncpy(address, wc + 26, 40);
        address[40] = '\0';

        char *pb_pos = strstr(validator_start, "\"principal_balance\": \"");
        if (!pb_pos) {
            pos += strlen("\"status\": \"active_ongoing\"");
            continue;
        }
        char *pb_start = pb_pos + strlen("\"principal_balance\": \"");
        char *pb_end = strchr(pb_start, '"');
        if (!pb_end) {
            pos += strlen("\"status\": \"active_ongoing\"");
            continue;
        }
        char pb_str[32];
        strncpy(pb_str, pb_start, pb_end - pb_start);
        pb_str[pb_end - pb_start] = '\0';
        unsigned long long pb = strtoull(pb_str, NULL, 10);

        add_to_list(&head, address, pb);

        pos = pb_end;
    }

    FILE *out = fopen("active.txt", "w");
    if (!out) {
        perror("Failed to create active.txt");
        free(buffer);
        return 1;
    }

    AddressNode *current = head;
    while (current != NULL) {
        unsigned long long eth = current->balance_gwei / 1000000000ULL;
        unsigned long long remainder = current->balance_gwei % 1000000000ULL;
        fprintf(out, "0x%s,%llu.%09llu\n", current->address, eth, remainder);
        current = current->next;
    }

    fclose(out);

    current = head;
    while (current != NULL) {
        AddressNode *temp = current;
        current = current->next;
        free(temp);
    }

    free(buffer);

    return 0;
}
