#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    FILE *file = fopen("withdrawaldone.txt", "r");
    if (!file) {
        perror("Failed to open withdrawaldone.txt");
        return 1;
    }

    double total = 0.0;
    char line[256];

    while (fgets(line, sizeof(line), file)) {
        // Find the space separating address and amount
        char *space = strchr(line, ' ');
        if (!space) {
            fprintf(stderr, "Skipping malformed line: %s", line);
            continue;
        }

        // Convert amount string to double
        char *endptr;
        double amount = strtod(space + 1, &endptr);
        
        if (endptr == space + 1) {  // Conversion failed
            fprintf(stderr, "Failed to parse amount in line: %s", line);
            continue;
        }

        total += amount;
    }

    fclose(file);

    // Print with full precision (up to 9 decimal places)
    printf("Total sum of all withdrawals: %.9f OVER\n", total);

    return 0;
}
