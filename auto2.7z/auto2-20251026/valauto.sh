#! /bin/zsh
cd
cd valsearch/api
rm exited.txt
rm active.txt
cd
cd auto2
curl -X GET "http://localhost:5052/eth/v1/beacon/states/finalized/validators" | jq >> val.txt && wait
sleep 1
./activelist
sleep 1
curl -X GET "http://localhost:5052/eth/v1/beacon/states/head/validators?status=active_exiting" | jq >> ev.txt && wait
./exited
sleep 1

cp ~/auto2/active.txt ~/valsearch/api
cp ~/auto2/exited.txt ~/valsearch/api

echo 'copy complete'
./remove.sh
cd
cd valsearch
git add ~/valsearch/api/active.txt
git add ~/valsearch/api/exited.txt
git commit -m 'snapshot'
git push
